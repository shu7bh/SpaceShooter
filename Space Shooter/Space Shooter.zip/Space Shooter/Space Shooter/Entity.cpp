#include "Entity.h"

Entity::Entity(int x, int y, char symbol, float speed)
	: x(x), y(y), symbol(symbol), speed(speed) {}