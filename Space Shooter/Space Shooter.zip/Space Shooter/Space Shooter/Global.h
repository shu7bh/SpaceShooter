#pragma once
#include <vector>
#include <string>
#include "Debris.h"
#include <memory>
#include <map>
#include <array>

namespace game {
	extern std::vector<std::string> field;
	extern std::vector<std::unique_ptr<Debris>> debris;
	const char free = ' ';
	enum class dir {
		left = 'a',
		right = 'd',
		free = ' ',
		up = 'w',
		down = 's'
	};
	extern int phealth, pscore;
	const std::array<char, 4> psymbol = { '/', ' ', '\\', '^'};
	void display(std::string);
	void init();
}

namespace debris {
	constexpr int debtypes = 3;
	const std::map<std::string, std::unique_ptr<Debris>> types = [] {
		std::map<std::string, std::unique_ptr<Debris>> temp;

		temp.insert(std::make_pair<std::string, std::unique_ptr<Debris>>("Common", std::unique_ptr<Debris>(new Debris(200, 100, 'o', 1.0f, 1))));

		temp.insert(std::make_pair<std::string, std::unique_ptr<Debris>>("Rare", std::unique_ptr<Debris>(new Debris(400, 200, '|', 0.5f, 2))));

		temp.insert(std::make_pair<std::string, std::unique_ptr<Debris>>("Legendary", std::unique_ptr<Debris>(new Debris(800, 400, '*', 0.125f, 5))));

		return temp;
	}();

	const std::array<const std::array<char, 4>, debtypes> shapes = 
	{
		std::array<char, 4>{'\\', '_', '/', 'o'},
		std::array<char, 4>{'_', '_', '_', '|'},
		std::array<char, 4>{'*', '*', '*', '*'}
	};
}

namespace fire {
	const std::map<std::string, std::unique_ptr<Fire>> types = [] {
		std::map <std::string, std::unique_ptr<Fire>> temp;

		temp.insert(std::make_pair<std::string, std::unique_ptr<Fire>>("Hand Gun", std::unique_ptr<Fire>(new Fire('`', 2.5f, 150))));

		temp.insert(std::make_pair<std::string, std::unique_ptr<Fire>>("Pistol", std::unique_ptr<Fire>(new Fire('.', 2.0f, 100))));

		temp.insert(std::make_pair<std::string, std::unique_ptr<Fire>>("Grenade", std::unique_ptr<Fire>(new Fire('+', 3.0f, 150))));

		temp.insert(std::make_pair<std::string, std::unique_ptr<Fire>>("Missile", std::unique_ptr<Fire>(new Fire(':', 4.0f, 300))));

		return temp;
	}();
}