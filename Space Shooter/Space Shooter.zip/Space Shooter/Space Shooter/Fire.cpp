#include "Fire.h"
#include "Global.h"
#include <algorithm>//	* For swap()
#include <array>

Fire::Fire(int x, int y, char symbol, float speed, int attack, char dir)
	: Entity(x, y, symbol, speed), attack(attack), dir(dir)
{
	if (symbol == fire::types.at("Hand Gun")->symbol)
		game::field[x - 2][y] = symbol, this->x -= 2;// The bullet is created on the game::field
	else
		game::field[x + 2][y] = symbol, this->x += 2;
}

Fire::Fire(char symbol, float speed, int attack)//		* For the creation of Bullet
	: Entity(INT_MAX, INT_MAX, symbol, speed), attack(attack), dir(static_cast<char>(game::dir::free)) {}//* Templates

bool Fire::move()
{
	if (destroy)
		return false;
	if (game::field[x][y] == game::free)
		return false;

	for (int i = 0; i < speed; i++)
		if (dir == static_cast<char>(game::dir::up))
			if (x == 0)//		* If the bullet has reached the top of the screen
				return false;// * The bullet will be destroyed
			else if (game::field[x - 1][y] == game::free)//	* If the next place is free the bullet
				std::swap(game::field[x][y], game::field[x - 1][y]), x--;//* will move there
			else if
				(
					std::any_of(debris::shapes[0].begin(), debris::shapes[0].end(), [x = x - 1, y = y](char ch){return game::field[x][y] == ch;}) ||
					std::any_of(debris::shapes[1].begin(), debris::shapes[1].end(), [x = x - 1, y = y](char ch){return game::field[x][y] == ch;}) ||
					std::any_of(debris::shapes[2].begin(), debris::shapes[2].end(), [x = x - 1, y = y](char ch){return game::field[x][y] == ch;})
					)
			{
				destroy = true;
				for (auto& deb : game::debris)
					if (x - 2 == deb->getx() && y == deb->gety() || x - 1 == deb->getx() && y - 1 == deb->gety() || x - 1 == deb->getx() && y + 1 == deb->gety())
						deb->setHealth(deb->getHealth() - attack);
			}
			else destroy = true;
		else
			if (x >= game::field.size() - 2)
				return false;
			else if (game::field[x + 1][y] == game::free)
				std::swap(game::field[x][y], game::field[x + 1][y]), x++;
			else if (game::field[x + 1][y] == fire::types.at("Hand Gun")->symbol)
				destroy = true;
			else if (std::any_of(game::psymbol.begin(), game::psymbol.end(), 
				[x = x + 1, y = y](char ch){return ch == game::field[x][y];}))
			{
				game::phealth -= attack;
				return false;
			}
	return true;// The bullet moves successfully
}

Fire::~Fire()
{
	if (y != INT_MAX)// Since the templatised bullets cannot be destroyed
		game::field[x][y] = game::free;// The bullet coordinates are freed from game::field 
}